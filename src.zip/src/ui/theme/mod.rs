//! Centralized UI theming: color palettes, typography, and styling helpers.
//!
//! Layout dimensions and spacing tokens have been moved to `crate::ui::layout`.
//! This module now focuses exclusively on colors, fonts, and visual effects.

use eframe::egui;

// ── Re-exports for backward compatibility ─────────────────────────────────────

/// Layout constants (window sizes, margins, spacing, animation timing).
/// Import from `crate::ui::layout` for new code.
pub use super::layout::*;

// ── Tray Theme ───────────────────────────────────────────────────────────────

/// Default tray icon color (hex string for SVG replacement).
pub const DEFAULT_ICON_COLOR: &str = "#95A5A6";

/// Tooltip text displayed when hovering the tray icon.
pub const APP_TOOLTIP: &str = "Blade ControlHub";

/// Title shown on the settings window frame.
pub const SETTINGS_WINDOW_TITLE: &str = "Blade ControlHub";

/// Gold color used for the settings icon SVG replacement.
pub const SETTINGS_ICON_COLOR: &str = "#FFD700";

// ── OSD Colors ───────────────────────────────────────────────────────────────

/// Raw RGBA components for the OSD background at full opacity.
/// Computed as `(30, 30, 30, 230)` before alpha multiplication.
pub const OSD_BACKGROUND_R: f32 = 30.0;
pub const OSD_BACKGROUND_G: f32 = 30.0;
pub const OSD_BACKGROUND_B: f32 = 30.0;
pub const OSD_BACKGROUND_A: f32 = 230.0;

/// Raw RGBA components for the OSD accent (gold) color.
/// Computed as `(255, 215, 0, 230)` before alpha multiplication.
pub const OSD_ACCENT_R: f32 = 255.0;
pub const OSD_ACCENT_G: f32 = 215.0;
pub const OSD_ACCENT_B: f32 = 0.0;
pub const OSD_ACCENT_A: f32 = 230.0;

/// Raw RGBA components for the OSD text (white).
/// Computed as `(255, 255, 255, 230)` before alpha multiplication.
pub const OSD_TEXT_R: f32 = 255.0;
pub const OSD_TEXT_G: f32 = 255.0;
pub const OSD_TEXT_B: f32 = 255.0;
pub const OSD_TEXT_A: f32 = 230.0;

// ── Strike-through Overlay ───────────────────────────────────────────────────

/// SVG path for the red diagonal strike-through line applied to "off" state icons.
#[allow(dead_code)]
pub const STRIKE_THROUGH_SVG: &str =
    r##"<path d="M2 22L22 2" stroke="#FF4444" stroke-width="2" stroke-linecap="round" />"##;

// ── Theme Helpers ────────────────────────────────────────────────────────────

/// Computes an OSD color with the given alpha factor applied for fade animations.
#[derive(Clone, Copy, Debug)]
pub struct OsdColors {
    /// Background fill color with alpha applied.
    pub background: egui::Color32,
    /// Accent (gold) color with alpha applied.
    pub accent: egui::Color32,
    /// Text (white) color with alpha applied.
    pub text: egui::Color32,
}

impl OsdColors {
    /// Creates a themed color set with the specified alpha (0.0 = invisible, 1.0 = full).
    #[inline]
    pub fn with_alpha(alpha: f32) -> Self {
        Self {
            background: egui::Color32::from_rgba_premultiplied(
                (Self::clamp(OSD_BACKGROUND_R * alpha)) as u8,
                (Self::clamp(OSD_BACKGROUND_G * alpha)) as u8,
                (Self::clamp(OSD_BACKGROUND_B * alpha)) as u8,
                (Self::clamp(OSD_BACKGROUND_A * alpha)) as u8,
            ),
            accent: egui::Color32::from_rgba_premultiplied(
                (Self::clamp(OSD_ACCENT_R * alpha)) as u8,
                (Self::clamp(OSD_ACCENT_G * alpha)) as u8,
                (Self::clamp(OSD_ACCENT_B * alpha)) as u8,
                (Self::clamp(OSD_ACCENT_A * alpha)) as u8,
            ),
            text: egui::Color32::from_rgba_premultiplied(
                (Self::clamp(OSD_TEXT_R * alpha)) as u8,
                (Self::clamp(OSD_TEXT_G * alpha)) as u8,
                (Self::clamp(OSD_TEXT_B * alpha)) as u8,
                (Self::clamp(OSD_TEXT_A * alpha)) as u8,
            ),
        }
    }

    #[inline]
    fn clamp(v: f32) -> f32 {
        v.clamp(0.0, 255.0)
    }
}

/// Overlays a red strike-through line onto an existing SVG icon by inserting
/// it just before the closing `</svg>` tag.
#[allow(dead_code)]
pub fn with_strikethrough(base_svg: &[u8]) -> Vec<u8> {
    let base = std::str::from_utf8(base_svg).expect("SVG asset must be valid UTF-8");
    base.replacen("</svg>", &format!("{STRIKE_THROUGH_SVG}\n</svg>"), 1)
        .into_bytes()
}
