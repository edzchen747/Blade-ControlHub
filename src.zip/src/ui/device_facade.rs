/// A facade trait abstracting device operations for the UI layer.
///
/// This trait isolates the UI from the concrete `DeviceHandle` implementation,
/// enabling testability and clean dependency inversion. The UI layer should
/// interact with devices exclusively through this interface.
#[allow(dead_code)]
pub trait DeviceFacade: Clone + Send + Sync + 'static {
    /// Returns the current application configuration from the device.
    fn get_config(&self) -> crate::error::AppResult<crate::razer::config::AppConfig>;

    /// Shuts down the device gracefully.
    fn shutdown(&self) -> crate::error::AppResult<bool>;

    /// Returns whether default multimedia key bindings are enabled.
    fn get_default_multimedia_keys(&self) -> crate::error::AppResult<bool>;

    /// Toggles default multimedia key bindings and returns the new state.
    fn toggle_default_multimedia_keys(&self) -> crate::error::AppResult<bool>;
}

use crate::razer::device_handle::DeviceHandle;

impl DeviceFacade for DeviceHandle {
    fn get_config(&self) -> crate::error::AppResult<crate::razer::config::AppConfig> {
        DeviceHandle::get_config(self)
    }

    fn shutdown(&self) -> crate::error::AppResult<bool> {
        DeviceHandle::shutdown(self)
    }

    fn get_default_multimedia_keys(&self) -> crate::error::AppResult<bool> {
        DeviceHandle::get_default_multimedia_keys(self)
    }

    fn toggle_default_multimedia_keys(&self) -> crate::error::AppResult<bool> {
        DeviceHandle::toggle_default_multimedia_keys(self)
    }
}
